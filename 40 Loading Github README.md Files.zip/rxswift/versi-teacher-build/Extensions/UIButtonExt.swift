//
//  UIButtonExt.swift
//  versi-teacher-build
//
//  Created by Caleb Stultz on 8/2/17.
//  Copyright © 2017 Caleb Stultz. All rights reserved.
//

import UIKit

extension UIButton {
    func setSelectedColor() {
        self.backgroundColor = darkPurple
    }
    
    func setDeselectedColor() {
        self.backgroundColor = lightPurple
    }
}
