//
//  AppDelegate.swift
//  RxExample
//
//  Created by Krunoslav Zaher on 5/19/15.
//  Copyright © 2015 Krunoslav Zaher. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {
    
    func applicationDidFinishLaunching(aNotification: Notification) {
        // Insert code here to initialize your application
    }
    
    func applicationWillTerminate(aNotification: Notification) {
        // Insert code here to tear down your application
    }
    
    
}
