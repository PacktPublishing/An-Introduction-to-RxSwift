//
//  TrendingFeedVC.swift
//  versi-app
//
//  Created by Caleb Stultz on 9/5/17.
//  Copyright © 2017 Caleb Stultz. All rights reserved.
//

import UIKit

class TrendingFeedVC: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}

